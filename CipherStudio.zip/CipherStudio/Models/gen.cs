﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace CipherStudio.Models
{
    public enum gen
    {
        Male=1,
        Female=2
    }
}