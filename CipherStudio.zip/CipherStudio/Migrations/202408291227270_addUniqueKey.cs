namespace CipherStudio.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class addUniqueKey : DbMigration
    {
        public override void Up()
        {
            CreateIndex("dbo.Classes", "ClassName", unique: true);
        }
        
        public override void Down()
        {
            DropIndex("dbo.Classes", new[] { "ClassName" });
        }
    }
}
